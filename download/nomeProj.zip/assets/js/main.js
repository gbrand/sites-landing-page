$(document).ready(function(){
	// Botão de teste
	$("#teste").click(function(){
		alert("That's ok, go hard!!");
	});
});